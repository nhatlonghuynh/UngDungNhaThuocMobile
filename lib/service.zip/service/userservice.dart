import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:nhathuoc_mobilee/api/userapi.dart';
import 'package:nhathuoc_mobilee/manager/usermanager.dart';

class ProfileService {
  final ProfileRepository _repository = ProfileRepository();

  // --- LOGIC CẬP NHẬT PROFILE ---
  Future<Map<String, dynamic>> updateProfile({
    required String name,
    required String phoneNumber,
    required String gender,
    required String birthday,
  }) async {
    try {
      final response = await _repository.updateProfileRequest({
        'Name_Customer': name,
        'PhoneNumber': phoneNumber,
        'Gender': gender,
        'Email': "", // Tùy chọn
        'Birthday': birthday,
      });

      if (response.statusCode == 200) {
        // Cập nhật thành công -> Lưu ngay vào bộ nhớ máy
        final userMgr = UserManager();
        userMgr.hoTen = name;
        userMgr.soDienThoai = phoneNumber;
        userMgr.gioiTinh = gender;
        userMgr.ngaySinh = birthday;
        // Lưu xuống đĩa (nếu UserManager có hàm saveUser cập nhật lại cache)
        // userMgr.saveUser(...);

        return {'success': true, 'message': 'Cập nhật thành công'};
      } else {
        return _handleError(response);
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  // --- LOGIC ĐỔI MẬT KHẨU ---
  Future<Map<String, dynamic>> changePassword(
    String oldPass,
    String newPass,
  ) async {
    try {
      final response = await _repository.changePasswordRequest({
        'OldPassword': oldPass,
        'NewPassword': newPass,
        'ConfirmPassword': newPass,
      });

      if (response.statusCode == 200) {
        return {'success': true, 'message': 'Đổi mật khẩu thành công'};
      } else {
        return _handleError(response);
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  // --- LOGIC QUÊN MẬT KHẨU ---
  Future<Map<String, dynamic>> forgotPassword(String username) async {
    try {
      final response = await _repository.forgotPasswordRequest(username);
      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': data['message'],
          'resetToken': data['resetToken'], // Token để dùng bước sau
        };
      } else {
        return _handleError(response);
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  // --- LOGIC RESET MẬT KHẨU ---
  Future<Map<String, dynamic>> resetPassword({
    required String username,
    required String token,
    required String newPassword,
  }) async {
    try {
      final response = await _repository.resetPasswordRequest({
        'Username': username,
        'Token': token,
        'NewPassword': newPassword,
        'ConfirmPassword': newPassword,
      });

      if (response.statusCode == 200) {
        return {'success': true, 'message': 'Đặt lại mật khẩu thành công'};
      } else {
        return _handleError(response);
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  // Helper xử lý lỗi
  Map<String, dynamic> _handleError(http.Response response) {
    try {
      final data = jsonDecode(response.body);
      String msg = data['message'] ?? "Có lỗi xảy ra";

      // Xử lý ModelState của ASP.NET
      if (data['ModelState'] != null) {
        msg = data['ModelState'].values.first[0];
      }
      return {'success': false, 'message': msg};
    } catch (_) {
      return {
        'success': false,
        'message': 'Lỗi server: ${response.statusCode}',
      };
    }
  }
}
