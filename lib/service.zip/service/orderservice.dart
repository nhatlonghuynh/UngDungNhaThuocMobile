import 'dart:convert';
import 'package:nhathuoc_mobilee/api/orderapi.dart';
import 'package:nhathuoc_mobilee/manager/usermanager.dart';
import 'package:nhathuoc_mobilee/models/giohang.dart';

class OrderService {
  final OrderRepository _repo = OrderRepository();

  // --- PHẦN 1: TÍNH TOÁN (Pure Logic) ---

  double calcSubtotal(List<GioHang> items) {
    return items.fold(0, (sum, item) => sum + (item.donGia * item.soLuong));
  }

  double calcShippingFee(int deliveryMethod) {
    // 0: Giao tận nơi (30k), 1: Nhận tại quầy (0đ)
    return deliveryMethod == 0 ? 30000 : 0;
  }

  double calcPointDiscount(int points) => points * 10.0; // 1 điểm = 10đ

  double calcFinalTotal({
    required double subtotal,
    required double shipping,
    required double discount,
  }) {
    double total = subtotal + shipping - discount;
    return total > 0 ? total : 0;
  }

  int calcEarnedPoints(double total) => (total / 10000).floor();

  // --- PHẦN 2: XỬ LÝ DỮ LIỆU API ---

  Future<Map<String, dynamic>> submitOrder({
    required List<GioHang> items,
    required String note,
    required double pointDiscount,
    required String paymentMethod,
    required String diaChi,
  }) async {
    print("DEBUG CHECK PAYMENT: '$paymentMethod'");
    // Map dữ liệu sang JSON server cần
    final listSanPhams = items
        .map(
          (item) => {
            "MaSP": item.maThuoc,
            "SoLuong": item.soLuong,
            "GiaThucTe": item.donGia,
          },
        )
        .toList();

    final body = {
      "MaKH": UserManager().userId,
      "GhiChu": note,
      "GiamGiaVoucher": 0,
      "GiamGiaDiem": pointDiscount,
      "SanPhams": listSanPhams,
      "PaymentMethod": paymentMethod, 
      "DiaChiNhanHang":diaChi,
    };

    try {
      final response = await _repo.createOrderApi(body);
      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          "success": true,
          "CheckoutUrl": data["CheckoutUrl"],
          "MaHD": data["maHD"],
          "payOSOrderCode": data["orderCode"],
        };
      } else {
        throw Exception(data['Message'] ?? "Tạo đơn thất bại");
      }
    } catch (e) {
      throw Exception("Lỗi Service: $e");
    }
  }

  Future<void> confirmPayment(int maHD, int code) async {
    final response = await _repo.confirmPaymentApi(maHD, code);
    if (response.statusCode != 200) {
      throw Exception("Lỗi xác nhận thanh toán");
    }
  }
}
