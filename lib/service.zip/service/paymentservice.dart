import 'package:nhathuoc_mobilee/models/giohang.dart';

class PaymentService {
  double calcSubtotal(List<GioHang> items) {
    return items.fold(0, (sum, item) => sum + item.donGia * item.soLuong);
  }

  double calcPointDiscount(int points) => points * 10.0;

  double calcShippingFee(int deliveryMethod) {
    return deliveryMethod == 1 ? 0 : 30000;
  }

  double calcFinalTotal({
    required double subtotal,
    required double shipping,
    required double voucherDiscount,
    required double pointDiscount,
  }) {
    return (subtotal + shipping - voucherDiscount - pointDiscount).clamp(
      0,
      double.infinity,
    );
  }

  int calcEarnedPoints(double total) => (total / 1000).floor();

  bool validateAddress(int deliveryMethod, String address) {
    if (deliveryMethod == 0 && address == "Chưa chọn địa chỉ") return false;
    return true;
  }
}
