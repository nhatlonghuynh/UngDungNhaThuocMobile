import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:nhathuoc_mobilee/models/useraddress.dart';

class UserAddressService {
  final String baseUrl = "http://192.168.2.9:8476/api/UserAddress";

  Future<List<UserAddress>> getAddresses(String userId) async {
    final response = await http.get(Uri.parse("$baseUrl/$userId"));
    if (response.statusCode == 200) {
      List data = json.decode(response.body);
      return data.map((e) => UserAddress.fromJson(e)).toList();
    } else {
      throw Exception("Failed to load addresses");
    }
  }

  Future<void> addAddress(String userId, UserAddress addr) async {
    final response = await http.post(
      Uri.parse("$baseUrl/$userId"),
      headers: {"Content-Type": "application/json"},
      body: json.encode(addr.toJson()),
    );
    if (response.statusCode != 200) {
      throw Exception("Failed to add address");
    }
  }

  Future<void> updateAddress(UserAddress addr) async {
    final response = await http.put(
      Uri.parse("$baseUrl/${addr.addressID}"),
      headers: {"Content-Type": "application/json"},
      body: json.encode(addr.toJson()),
    );
    if (response.statusCode != 200) {
      throw Exception("Failed to update address");
    }
  }

  Future<void> deleteAddress(int addressID) async {
    final response = await http.delete(Uri.parse("$baseUrl/$addressID"));
    if (response.statusCode != 200) {
      throw Exception("Failed to delete address");
    }
  }
}
