import 'dart:convert';

import 'package:nhathuoc_mobilee/api/order_history.dart';
import 'package:nhathuoc_mobilee/models/donhang.dart';

class OrderHistoryService {
  final OrderHistoryRepository _repo = OrderHistoryRepository();

  Future<Map<String, dynamic>> fetchOrders(String status) async {
    try {
      final response = await _repo.getOrderHistory(status);
      print("STATUS CODE: ${response.statusCode}");
      // In 500 ký tự đầu xem nó là trang gì (Login hay 404)
      print(
        "BODY PREVIEW: ${response.body.substring(0, response.body.length > 500 ? 500 : response.body.length)}",
      );
      // --- DEBUG QUAN TRỌNG ---
      print("API URL: ${response.request?.url}");
      print("STATUS CODE: ${response.statusCode}");
      // -----------------------

      if (response.statusCode == 200) {
        // Chỉ decode khi thành công 200
        final List<dynamic> rawList = jsonDecode(response.body);
        final orders = rawList.map((e) => OrderSummary.fromJson(e)).toList();
        return {'success': true, 'data': orders};
      } else if (response.statusCode == 401) {
        return {'success': false, 'message': 'Phiên đăng nhập hết hạn (401)'};
      } else if (response.statusCode == 404) {
        return {'success': false, 'message': 'Sai đường dẫn API (404)'};
      } else {
        // Nếu lỗi 500 hoặc lỗi khác, không decode body để tránh crash
        return {
          'success': false,
          'message':
              'Lỗi Server (${response.statusCode}). Vui lòng thử lại sau.',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi xử lý: $e'};
    }
  }

  Future<Map<String, dynamic>> fetchDetail(int orderId) async {
    try {
      final response = await _repo.getOrderDetail(orderId);

      if (response.statusCode == 200) {
        final rawData = jsonDecode(response.body);
        final detail = OrderDetail.fromJson(rawData);
        return {'success': true, 'data': detail};
      } else {
        return {'success': false, 'message': 'Không tìm thấy đơn hàng'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }

  Future<Map<String, dynamic>> cancelOrder(int orderId) async {
    try {
      final response = await _repo.cancelOrder(orderId);

      print("CANCEL STATUS: ${response.statusCode}");
      print("CANCEL BODY: ${response.body}");

      if (response.statusCode == 200) {
        return {'success': true, 'message': 'Hủy thành công'};
      } else {
        // Có thể server trả về lỗi 400 nếu đơn đã hủy rồi hoặc không cho hủy
        final body = jsonDecode(response.body);
        return {
          'success': false,
          'message': body['Message'] ?? 'Không thể hủy đơn hàng này',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Lỗi kết nối: $e'};
    }
  }
}
