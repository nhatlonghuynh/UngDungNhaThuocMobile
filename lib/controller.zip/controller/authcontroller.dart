import 'package:flutter/material.dart';
import 'package:nhathuoc_mobilee/service/authservice.dart';
import 'package:nhathuoc_mobilee/manager/usermanager.dart';

class AuthController extends ChangeNotifier {
  final AuthService _service = AuthService();

  // ---------------------------------------------------------------------------
  // STATE UI
  // ---------------------------------------------------------------------------
  bool isLoading = false;      // Hiển thị loading button
  bool obscureText = true;     // Ẩn/hiện mật khẩu

  // ---------------------------------------------------------------------------
  // GETTER: Kiểm tra đăng nhập
  // ---------------------------------------------------------------------------
  bool get isLoggedIn => UserManager().isLoggedIn;

  // ---------------------------------------------------------------------------
  // 1. Toggle hiển thị mật khẩu
  // ---------------------------------------------------------------------------
  void togglePasswordVisibility() {
    obscureText = !obscureText;
    notifyListeners();        // Cập nhật UI
  }

  // ---------------------------------------------------------------------------
  // 2. Đăng nhập
  // ---------------------------------------------------------------------------
  Future<Map<String, dynamic>> handleLogin(String phone, String pass) async {
    if (phone.isEmpty || pass.isEmpty) {
      return {'success': false, 'message': 'Vui lòng nhập đầy đủ thông tin'};
    }

    isLoading = true;
    notifyListeners();

    final result = await _service.login(phone, pass);

    isLoading = false;
    notifyListeners();

    return result;
  }

  // ---------------------------------------------------------------------------
  // 3. Đăng ký
  // ---------------------------------------------------------------------------
  Future<Map<String, dynamic>> handleRegister({
    required String name,
    required String phone,
    required String pass,
    required String confirmPass,
    required String gender,
  }) async {
    if (name.isEmpty || phone.isEmpty || pass.isEmpty) {
      return {'success': false, 'message': 'Vui lòng điền thông tin bắt buộc'};
    }
    if (pass != confirmPass) {
      return {'success': false, 'message': 'Mật khẩu xác nhận không khớp'};
    }

    isLoading = true;
    notifyListeners();

    final result = await _service.register(
      name: name,
      phone: phone,
      address: "address",   // placeholder tạm
      password: pass,
      gender: gender,
    );

    isLoading = false;
    notifyListeners();

    return result;
  }

  // ---------------------------------------------------------------------------
  // 4. Đăng xuất
  // ---------------------------------------------------------------------------
  Future<void> logout() async {
    await UserManager().logout(); // Xóa session
    notifyListeners();            // Cập nhật UI về trạng thái Guest
  }

  // ---------------------------------------------------------------------------
  // 5. Làm mới UI / load lại thông tin user
  // ---------------------------------------------------------------------------
  void refresh() {
    notifyListeners();
  }
}
