import 'package:flutter/material.dart';
import 'package:nhathuoc_mobilee/manager/usermanager.dart';
import 'package:nhathuoc_mobilee/models/donhang.dart';
import 'package:nhathuoc_mobilee/service/historyservice.dart';

class OrderHistoryController extends ChangeNotifier {
  final OrderHistoryService _service = OrderHistoryService();

  // State Danh sách
  List<OrderSummary> orders = [];
  bool isLoadingList = false;
  String errorList = '';

  // State Chi tiết
  OrderDetail? currentDetail;
  bool isLoadingDetail = false;
  String errorDetail = '';

  // --- LẤY DANH SÁCH ĐƠN HÀNG ---
  Future<void> getMyOrders(String status) async {
    // Nếu đang load dở thì thôi, tránh gọi chồng chéo (Optional)
    if (isLoadingList) return;

    isLoadingList = true;
    errorList = '';
    // orders.clear(); // <--- NÊN BỎ DÒNG NÀY ĐỂ TRÁNH NHÁY MÀN HÌNH
    notifyListeners();

    // 1. Kiểm tra Login
    String userId = UserManager().userId;
    print("DEBUG CHECK: UserId = '$userId'");

    // Nếu lỡ UserManager chưa load xong, thử load lại lần nữa cho chắc (Safety)
    if (userId.isEmpty) {
      await UserManager().loadUser();
      userId = UserManager().userId;
    }

    if (userId.isEmpty) {
      isLoadingList = false;
      errorList = 'Vui lòng đăng nhập lại';
      notifyListeners();
      return;
    }

    // 2. Gọi Service
    final result = await _service.fetchOrders(status);

    isLoadingList = false;

    if (result['success']) {
      orders = result['data'];
    } else {
      errorList = result['message'];
      print("DEBUG CHECK: API Error = '$errorList'"); // Sửa lại label cho đúng

      // Xử lý hết hạn token
      if (result['message'].toString().contains("401")) {
        // Logic logout hoặc refresh token ở đây
      }
    }
    notifyListeners();
  }

  // --- LẤY CHI TIẾT ĐƠN HÀNG ---
  Future<void> getOrderDetail(int orderId) async {
    isLoadingDetail = true;
    errorDetail = '';
    currentDetail = null;
    notifyListeners();

    final result = await _service.fetchDetail(orderId);

    isLoadingDetail = false;
    if (result['success']) {
      currentDetail = result['data'];
    } else {
      errorDetail = result['message'];
    }
    notifyListeners();
  }

  Future<bool> cancelOrder(int orderId) async {
    // Gọi service
    final result = await _service.cancelOrder(orderId);

    if (result['success']) {
      // Nếu đang ở màn hình danh sách -> Reload lại danh sách hiện tại
      // (Mẹo: Reload lại tab ALL hoặc tab hiện tại để cập nhật trạng thái)
      // getMyOrders("ALL");

      return true; // Báo cho UI biết là thành công
    } else {
      // Gán lỗi vào biến errorDetail (hoặc hiển thị Toast/Snackbar ở UI)
      errorDetail = result['message'];
      notifyListeners();
      return false; // Thất bại
    }
  }
}
