import 'package:flutter/material.dart';
import 'package:nhathuoc_mobilee/models/giohang.dart';
import 'package:nhathuoc_mobilee/service/cartservice.dart'; // Import Service

class CartController extends ChangeNotifier {
  // Singleton (theo code cũ của bạn)
  static final CartController _instance = CartController._internal();
  factory CartController() => _instance;
  CartController._internal();

  final CartService _service = CartService();

  // STATE (Trạng thái)
  List<GioHang> cartItems = [];
  bool isLoading = false;

  // 1. Tải dữ liệu
  Future<void> loadData() async {
    isLoading = true;
    notifyListeners(); // Báo cho UI (nếu dùng Provider/Listen)

    cartItems = await _service.getFullCartDetails();

    isLoading = false;
    notifyListeners();
  }

  // 2. Chọn tất cả / Bỏ chọn
  void toggleSelectAll(bool isSelected) {
    for (var item in cartItems) {
      item.isSelected = isSelected;
    }
    notifyListeners();
  }

  // 3. Thay đổi số lượng (+/-)
  Future<void> updateQuantity(int index, int change) async {
    // Cập nhật State tạm thời để UI mượt
    int newQty = cartItems[index].soLuong + change;
    if (newQty > 0) {
      cartItems[index].soLuong = newQty;
      notifyListeners();

      // Cập nhật ngầm xuống Service
      await _service.updateLocalCart(cartItems[index].maThuoc, change);
    }
  }

  // 4. Xóa sản phẩm
  Future<void> deleteItem(int index) async {
    int maThuoc = cartItems[index].maThuoc;

    // Xóa khỏi State UI
    cartItems.removeAt(index);
    notifyListeners();

    // Gọi Service xóa dưới máy
    await _service.removeLocalItem(maThuoc);
  }

  // 5. Getter tính toán
  double get totalPayment => _service.calculateTotal(cartItems);

  bool get isAllSelected =>
      cartItems.isNotEmpty && cartItems.every((e) => e.isSelected);

  List<GioHang> get selectedItems =>
      cartItems.where((e) => e.isSelected).toList();
}
