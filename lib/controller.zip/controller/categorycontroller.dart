import 'package:flutter/material.dart';
import 'package:nhathuoc_mobilee/api/categoryapi.dart';
import 'package:nhathuoc_mobilee/models/DanhMuc.dart';

class CategoryController extends ChangeNotifier {
  final ApiService _service = ApiService();
  List<LoaiDanhMuc> tree = [];
  bool isLoading = false;

  Future<void> loadCategories() async {
    if (tree.isNotEmpty) return; // Đã tải rồi thì không tải lại
    isLoading = true;
    notifyListeners();
    tree = await _service.fetchCategoryTree();
    isLoading = false;
    notifyListeners();
  }
}